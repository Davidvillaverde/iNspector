

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;
import java.util.*;

/**
 * Servlet implementation class Prueba
 */
@WebServlet("/Buscador")
public class Buscador extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Buscador() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/DisplayInfo.jsp";
		
		String rotulo = request.getParameter("rotulo");
		
		List<String> rotulos = askDB(rotulo);
		
		request.setAttribute("rotulos", rotulos);
		
		getServletContext()
		.getRequestDispatcher(url)
		.forward(request, response);
		
	}
	
	protected List<String> askDB(String rotulo) {
		List<String> rotulos = new ArrayList<String>();
		
		try {
			Connection con;
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/isst?serverTimezone=UTC";
			String user = "cliente";
			String pw = "1234";
			int i = 0;
			
			con = DriverManager.getConnection(url, user, pw);
			
			Statement s = con.createStatement();
			
			String query = "SELECT DISTINCT r�tulo FROM inspecciones_isst WHERE r�tulo like '%" + rotulo + "%' ORDER BY r�tulo";
			
			ResultSet res = s.executeQuery(query);
			
			while ( res.next() ) {
                rotulos.add(res.getString(1));
                i++;
            }
			
			con.close();
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
		finally {
			return rotulos;
		}
	}

}
