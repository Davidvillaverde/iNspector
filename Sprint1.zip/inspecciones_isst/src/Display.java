

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import inspecciones_isst.Inspeccion;

/**
 * Servlet implementation class Display
 */
@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Display() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/DisplayLocal.jsp";
		
		String rotulo = request.getParameter("rotulo");
		
		Inspeccion local = new Inspeccion();
		
		local = askDB(rotulo);
		
		request.setAttribute("local", local);
		
		getServletContext()
		.getRequestDispatcher(url)
		.forward(request, response);
		
	}
	
	protected Inspeccion askDB(String rotulo) {
		Inspeccion local = new Inspeccion();
		
		try {
			Connection con;
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/isst?serverTimezone=UTC";
			String user = "cliente";
			String pw = "1234";
			int i = 0;
			
			con = DriverManager.getConnection(url, user, pw);
			
			Statement s = con.createStatement();
			
			String query = "SELECT * FROM inspecciones_isst WHERE r�tulo = '" + rotulo + "' ORDER BY Fecha_de_la_inspecci�n";
			
			ResultSet res = s.executeQuery(query);
			
			res.first();
			local.setId(res.getInt(1));
			local.setRotulo(res.getString(2));
			local.setDireccion(res.getString(3));
			local.setActividad(res.getString(4));
			local.setFecha(res.getString(5));
			local.setTipo_actuacion(res.getString(6));
			local.setPerfil_actividad(res.getString(7));
			local.setEstado_sanitario(res.getString(8));
			local.setF_inspeccion(res.getString(9));
			
			con.close();
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
		finally {
			return local;
		}
	}

}
